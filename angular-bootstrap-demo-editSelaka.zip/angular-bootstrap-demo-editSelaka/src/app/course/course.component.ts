import { Component, OnInit } from '@angular/core';
import {CourseService}from '../course.service';
import { Course } from '../course.model';
@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course : {id,cname, cduration,coursetype,faculty,prerequisites} = {id :null, cname:" ", cduration :" ",coursetype:" ",faculty:" ",prerequisites:" "};
  updatingCourse:any;
  constructor(public dataService:CourseService) { }

  ngOnInit() {
    this.updatingCourse=this.dataService.getCourseId()
    if(this.updatingCourse){
    this.dataService.getCourseByID(this.updatingCourse.CourseID).subscribe((fetchedUpdatingCourse)=>{
      this.updatingCourse=fetchedUpdatingCourse;
     })
    }
  }

  postUpdatedCourse(courseDetailsToUpdate:Course){
    this.dataService.putCourse(courseDetailsToUpdate);
  }

}

export class Course {
CourseID:number;
CourseName:string;
CourseDuration:string;
CourseType:string;
FacultyOffer:string;
CoursePrerequisites:string;
}

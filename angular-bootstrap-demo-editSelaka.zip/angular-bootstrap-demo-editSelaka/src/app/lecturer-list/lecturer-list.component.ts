import { Component, OnInit } from '@angular/core';
import { LecturerService } from '../lecturer.service';
@Component({
  selector: 'app-lecturer-list',
  templateUrl: './lecturer-list.component.html',
  styleUrls: ['./lecturer-list.component.css']
})
export class LecturerListComponent implements OnInit {
  lecturers;
  selectedLecturer;

  constructor(public dataService:LecturerService) { }

  ngOnInit() {
    this.lecturers= this.dataService.getLecturers();
  }

  public selectLecturer(lecturer){
    this.selectedLecturer = lecturer ;
  }

}

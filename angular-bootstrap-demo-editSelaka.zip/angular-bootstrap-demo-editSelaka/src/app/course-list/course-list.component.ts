import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  courses;
  selectedCourse;

  constructor(public dataService:CourseService, public router:Router) { }

  ngOnInit() {
    this.courses= this.dataService.getCourses();
  }
  public selectCourse(course){
    this.selectedCourse = course ;
  }

  public updateCourse(course:any){
    this.dataService.setCourseId(course);
    this.router.navigate(['/route to navigate']);
  }

}

import { Component, OnInit } from '@angular/core';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit {

  courses;
  selectedCourse;

  constructor(public dataService:CourseService) { }

  ngOnInit() {
    this.courses= this.dataService.getCourses();
  }
  public selectCourse(course){
    this.selectedCourse = course ;
  }

}

import { Component, OnInit } from '@angular/core';
import { EnrollmentService } from '../enrollment.service';

@Component({
  selector: 'app-enrollment-list',
  templateUrl: './enrollment-list.component.html',
  styleUrls: ['./enrollment-list.component.css']
})
export class EnrollmentListComponent implements OnInit {
  enrollments;
  selectedEnrollment;

  constructor(public dataService:EnrollmentService) { }

  ngOnInit() {
    this.enrollments= this.dataService.getEnrollments();
  }
  public selectEnrollment(enrollment){
    this.selectedEnrollment = enrollment;
  }
}

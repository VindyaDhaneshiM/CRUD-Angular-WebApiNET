import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lecturer',
  templateUrl: './lecturer.component.html',
  styleUrls: ['./lecturer.component.css']
})
export class LecturerComponent implements OnInit {
  lecturer : {id,fname, lname,dob,doj,email,gender, address,category,contract,qualification} = {id :null, fname:" ", lname :" ",dob:" ",doj:" ",email:" ",gender:" ", address:" ",category:" ",contract:" ",qualification:" "};
  constructor() { }

  ngOnInit() {
  }

}

import { Injectable } from '@angular/core';
import {HttpClient } from "@angular/common/http";
import { Student } from './student.model';
import { StudentListComponent } from './student-list/student-list.component';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData : Student;
  list : Student[];
  alldatas:Student;
  readonly rootURL="https://localhost:5001/api"
// ---
  students = [
    {id: 1, fname: "Saman",lname:"Perera" , dob: "10-03-1990",email:"sam@gmail.com", gender: "Male",address:"No 5 Temple Road Colombo"},
    {id: 2, fname: "Nimal",lname:"Silva" , dob: "20-05-1995",email:"nim@gmail.com", gender: "Male",address:"No 7 Flowers Road Colombo"},
    {id: 3, fname: "Kusum",lname:"Senarathna" , dob: "17-04-1992",email:"kus@gmail.com", gender: "Female",address:"No 15 StAnthoney Road Kadana"},
    {id: 4, fname: "Ruwan",lname:"Gunasekara" , dob: "22-03-1990",email:"run@gmail.com", gender: "Male",address:"No 5 Temple Road Colombo"}
  ];
  public getStudents():Array<{id,fname, lname,dob,email,gender, address}>{
    return this.students;
  }
  public createStudent(contact: {id,fname, lname,dob,email,gender, address}){
    this.students.push(contact);
  }
// ----
  constructor(private http:HttpClient) { }

  postStudent( formData : Student){
    this.alldatas=formData;
    return this.http.post(this.rootURL+'/student',formData)
  }
  
  refreshList(){
  this.http.get(this.rootURL+"/Student")
  .toPromise()
  .then(res => {this.list = res as Student[];
  });
  }
  
  putStudent(formData:Student){
    this.alldatas=formData;
  return this.http.put(this.rootURL+'/student/'+formData.StudentID,formData);
  }
  deleteStudent(id : number)
  {
  return this.http.delete(this.rootURL+'/student/'+id);
  }
  getStudent(){
    return this.http.get(this.rootURL+'/student');
  }
  //get a particular student
  GetStudent(id : number){
  
  return this.http.get(this.rootURL+'/student/'+id);
  }
  
  
  editStudentRow(data){
    console.log(data);
    return data;
  }
}

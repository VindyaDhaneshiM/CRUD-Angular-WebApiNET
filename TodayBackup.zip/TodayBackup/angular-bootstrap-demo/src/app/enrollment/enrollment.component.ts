import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {
  lecturer : {id,edate, sid,sname,cid,cname,estatus,cfee, installments,installmentspay} = {id :null, edate:"", sid :" ",sname:" ",cid:" ", cname:"",estatus:" ",cfee:" ", installments:" ",installmentspay:" "};
  constructor() { }

  ngOnInit() {
  }

}
